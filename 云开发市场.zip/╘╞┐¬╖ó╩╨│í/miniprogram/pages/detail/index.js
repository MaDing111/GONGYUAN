// pages/detail/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods:"",
    describe:"",
    images:"",
    oldprice:"",
    phonenumber:"",
    place:"",
    price:"",
    sort:"",
    title:"",
    way:"",
    wechat:"",
  },
  //获取传来的数据

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({title: '数据加载中'})
  this.setData({
    describe:options.describe,
    images:options.images,
    oldprice:options.oldprice,
    phonenumber:options.phonenumber,
    place:options.place,
    price:options.price,
    sort:options.sort,
    title:options.title,
    way:options.way,
    wechat:options.wechat,
  })
  wx.hideLoading({})
  let that=this
  wx.cloud.database().collection('goods').get().then(res=>{
    that.setData({
      goods:res.data
    })
    wx.hideLoading({
    
    })
  })
  },
    //去往详情页面
  details:function(event){
    let {describe,images,oldprice,phonenumber,place,price,sort,title,way,wechat}=event.currentTarget.dataset
    wx.navigateTo({
      url: `../detail/index?describe=${describe}&images=${images}&oldprice=${oldprice}&phonenumber=${phonenumber}&place=${place}&price=${price}&sort=${sort}&title=${title}&way=${way}&wechat=${wechat}`,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})