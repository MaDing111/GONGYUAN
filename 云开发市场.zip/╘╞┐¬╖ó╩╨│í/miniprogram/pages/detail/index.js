// pages/detail/index.js
const api = require("../../api/api")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detailList:[],
    likeList:[],
  },
  //获取传来的数据

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({title: '数据加载中'})
    console.log("传的id",options.id)
      //获取热门商品
    api.find("newgoods",{_id:options.id}).then(res=>{
      console.log("获取到了商品",res.data[0])
      this.setData({
        detailList:res.data[0]
      }) 
    })
    console.log("传的sort",options.sort)
    api.find("newgoods",{sort:options.sort}).then(res=>{
      console.log("获取喜欢商品",res.data)
      this.setData({
        likeList:res.data
      }) 
      wx.hideLoading({})
    })
  },
    //去往详情页面
  details:function(event){
    let {id}=event.currentTarget.dataset
    wx.navigateTo({
      url: `../detail/index?id=${id}`,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})