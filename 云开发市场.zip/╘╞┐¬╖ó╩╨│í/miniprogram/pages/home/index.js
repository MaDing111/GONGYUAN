
Page({

  data: {
    goods:"",
    current: 0,  //当前所在页面的 index
    indicatorDots: true,
    autoplay: true, //是否自动切换
    interval: 2000, //自动切换时间间隔
    duration: 800, //滑动动画时长
    circular: true, //是否采用衔接滑动
    inputShowed: false,
    inputVal: "",
    selected: true,
    selected1: false,
    selected2: false,
    selected3: false,
    selected4: false,
    imgUrls: [
      'cloud://cloud1-0gf5m759066b9527.636c-cloud1-0gf5m759066b9527-1306520679/images/lun1.png',
      'cloud://cloud1-0gf5m759066b9527.636c-cloud1-0gf5m759066b9527-1306520679/images/lun2.png',
      'cloud://cloud1-0gf5m759066b9527.636c-cloud1-0gf5m759066b9527-1306520679/images/lun3.jpg'
    ],
    //轮播图的切换事件
    swiperChange: function (e) {
      this.setData({
        swiperCurrent: e.detail.current
      })
    },
    //点击指示点切换
    //点击图片触发事
  },
  switchItemEvent(event) {
    const key = event.detail.index
    console.log(event)
    let currentType = ''
    switch (key) {
      case 0:
        currentType = HIT
        break;
      case 1:
        currentType = SOON
        break;
      case 2:
        currentType = BOARD
        break;
    }
    this.setData({
      currentType: currentType
    })
  },
  //搜索框
  tabChange(e) {
    console.log('tab change', e)
  },
  onLoad() {
    wx.showLoading({
      title: '数据加载中',
    })
    //获取商品
    let that=this
    wx.cloud.database().collection('goods').get().then(res=>{
 
      that.setData({
        goods:res.data
      })
      wx.hideLoading({
      
      })
    })
    this.setData({
      search: this.search.bind(this), 
    })
   
    
  },

  search: function (value) {
    return new Promise((resolve, reject) => {
      
    })
  },
    //搜索结果
  selectResult: function (e) {
    console.log('select result', e.detail)
  },

 
  selected: function (e) {
    this.setData({
      selected: true,
      selected1: false,
      selected2: false,
      selected3: false,
      selected4: false
    })
  },
  selected1: function (e) {
    this.setData({
      selected: false,
      selected1: true,
      selected2: false,
      selected3: false,
      selected4: false
    })
  },
  selected2: function (e) {
    this.setData({
      selected: false,
      selected1: false,
      selected2: true,
      selected3: false,
      selected4: false
    })
  },
  selected3: function (e) {
    this.setData({
      selected: false,
      selected1: false,
      selected2: false,
      selected3: true,
      selected4: false
    })
  },
  selected4: function (e) {
    this.setData({
      selected: false,
      selected1: false,
      selected2: false,
      selected3: false,
      selected4: true
    })
  },
  //去往详情页面
  details:function(event){
    let {describe,images,oldprice,phonenumber,place,price,sort,title,way,wechat}=event.currentTarget.dataset
    wx.navigateTo({
      url: `../detail/index?describe=${describe}&images=${images}&oldprice=${oldprice}&phonenumber=${phonenumber}&place=${place}&price=${price}&sort=${sort}&title=${title}&way=${way}&wechat=${wechat}`,
    })
  }
});