const api = require("../../api/api")
Page({

  data: {
    hotList:[],
    hotList1:[],
    hotList2:[],
    hotList3:[],
    hotList4:[],
    peng:true,
    goods: "",
    current: 0,  //当前所在页面的 index
    indicatorDots: true,
    autoplay: true, //是否自动切换
    interval: 2000, //自动切换时间间隔
    duration: 800, //滑动动画时长
    circular: true, //是否采用衔接滑动
    inputShowed: false,
    inputVal: "",

    imgUrls: [
      'cloud://cloud1-0gf5m759066b9527.636c-cloud1-0gf5m759066b9527-1306520679/images/lun1.png',
      'cloud://cloud1-0gf5m759066b9527.636c-cloud1-0gf5m759066b9527-1306520679/images/lun2.png',
      'cloud://cloud1-0gf5m759066b9527.636c-cloud1-0gf5m759066b9527-1306520679/images/lun3.jpg'
    ],
    //轮播图的切换事件
    swiperChange: function (e) {
      this.setData({
        swiperCurrent: e.detail.current
      })
    },

  },
  //跳转到二手闲置
  intoold: function () {
    wx.navigateTo({
      url: '../old/index',
    });
  },
  //跳转到全新商品
  intonew: function () {
    wx.navigateTo({
      url: '../new/index',
    });
  },
  //搜索框
  tabChange(e) {
    console.log('tab change', e)
  },
 
  search: function (value) {
    return new Promise((resolve, reject) => {
    })
  },
  //搜索结果
  selectResult: function (e) {
    console.log('select result', e.detail)
  },
  onLoad() {
    wx.showLoading({
      title: '数据正在加载..',
    })
  },
  onShow:function(){
    this.getHotlist();
  },
  //获取热门商品
  getHotlist(){
    api.find("newgoods").then(res=>{
      this.setData({
        hotList:res.data
      })
        
      wx.hideLoading({})

    })
  },
  //去详情页
  details:function(event){
    let {id,sort}=event.currentTarget.dataset
    wx.navigateTo({
      url: `../detail/index?id=${id}&sort=${sort}`,
    })
  },
});