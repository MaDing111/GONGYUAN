//app.js
App({
  onLaunch: function () {
      wx.cloud.init({
        env: 'cloud1-0gf5m759066b9527',
      })
  },

})
wx.getSetting({
  success:(res)=>{
    //判断，已经授权，就可以直接使用用户信息
console.log(res)
  }
})